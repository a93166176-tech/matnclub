---
name: Matn Literary Experience
colors:
  surface: '#fcf9f3'
  surface-dim: '#dcdad4'
  surface-bright: '#fcf9f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ed'
  surface-container: '#f0eee8'
  surface-container-high: '#ebe8e2'
  surface-container-highest: '#e5e2dc'
  on-surface: '#1c1c18'
  on-surface-variant: '#414944'
  inverse-surface: '#31312d'
  inverse-on-surface: '#f3f0ea'
  outline: '#717974'
  outline-variant: '#c0c8c2'
  surface-tint: '#3c6754'
  primary: '#083727'
  on-primary: '#ffffff'
  primary-container: '#234e3d'
  on-primary-container: '#91bea8'
  inverse-primary: '#a3d1ba'
  secondary: '#715b32'
  on-secondary: '#ffffff'
  secondary-container: '#fedeaa'
  on-secondary-container: '#786137'
  tertiary: '#183528'
  on-tertiary: '#ffffff'
  tertiary-container: '#2f4c3e'
  on-tertiary-container: '#9bbcaa'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#beedd6'
  primary-fixed-dim: '#a3d1ba'
  on-primary-fixed: '#002115'
  on-primary-fixed-variant: '#244f3e'
  secondary-fixed: '#fedeaa'
  secondary-fixed-dim: '#e0c290'
  on-secondary-fixed: '#271900'
  on-secondary-fixed-variant: '#58441d'
  tertiary-fixed: '#c9ead7'
  tertiary-fixed-dim: '#adcebc'
  on-tertiary-fixed: '#022015'
  on-tertiary-fixed-variant: '#304d3f'
  background: '#fcf9f3'
  on-background: '#1c1c18'
  surface-variant: '#e5e2dc'
typography:
  display-hero:
    fontFamily: Libre Caslon Text
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 64px
  display-hero-mobile:
    fontFamily: Libre Caslon Text
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 44px
  headline-lg:
    fontFamily: Libre Caslon Text
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 44px
  headline-lg-mobile:
    fontFamily: Libre Caslon Text
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 34px
  headline-md:
    fontFamily: Libre Caslon Text
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 34px
  headline-sm:
    fontFamily: Libre Caslon Text
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Source Serif 4
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Source Serif 4
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 32px
  body-md:
    fontFamily: Source Serif 4
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 28px
  body-sm:
    fontFamily: Source Serif 4
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  label-lg:
    fontFamily: Source Serif 4
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Source Serif 4
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Source Serif 4
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a sanctuary for readers, thinkers, and cultural salons. Rooted in traditional literary dignity and contemporary digital craftsmanship, it crafts an intimate reading environment inspired by heavy parchment, deep botanical inks, and warm archival bindings.

### Brand Personality & Emotional Resonance
- **Intellectual Serenity:** Evoking the calm focus of a private library, shielding users from aggressive digital noise.
- **Archival Warmth:** Warm paper undertones replace sterile screen whites, easing ocular strain during prolonged literary engagement.
- **Subtle Prestige:** Dignified emerald green and warm gold accents denote scholarly authority and deliberate curation.

### Design Style Movement
- **Editorial Literary Minimalism:** Prioritizes generous margins, typographical hierarchy, tactile borders, and subtle parchment layering. Avoids excessive blur effects or loud gradients in favor of sharp typographic balance, hairline separator rules, and muted tactile micro-interactions suited for full RTL (Right-to-Left) reading flows.

## Colors

The palette directly honors classic bookmaking: organic botanical dyes, pressed unbleached parchment, and gilded foil stamps.

### Color Hierarchy & Roles
- **Primary (`#234E3D`):** Deep Forest Emerald. Serves as the primary brand anchor, high-emphasis text, primary action buttons, active navigation markers, and header identities.
- **Secondary (`#C2A676`):** Sand Dune Gold. Applied to literary seals, badges, loyalty point counters, subtle focus rings, and decorative hairline borders.
- **Tertiary (`#1B382B`):** Archival Cypress Ink. Used for maximum-contrast reading typography, deep headers, and high-priority administrative statuses.
- **Neutral Canvas (`#F9F6F0`):** Warm Book Vellum. The global viewport background, offering an anti-glare canvas reminiscent of high-grade paper stock.
- **Surface Layering:**
  - `surface-default`: `#F9F6F0` (Root viewport canvas)
  - `surface-raised`: `#FFFFFF` (Card surfaces, modals, reader containers)
  - `surface-muted`: `#F2EDE2` (Secondary inputs, table headers, inactive tabs)
  - `border-hairline`: `rgba(194, 166, 118, 0.28)` (Subtle literary divider line)
  - `text-body`: `#2B332F` (High legibility charcoal-green ink for dense reading)
  - `text-muted`: `#68746E` (Secondary captions, metadata, timestamps)

## Typography

The typographic hierarchy is calibrated for literary dignity, supporting bidirectional workflows and Arabic serif rendering (such as Amiri or Noto Kufi Arabic when serving Arabic scripts) paired harmoniously with Latin counterparts.

### Editorial Guidelines
- **Leading & Rhythm:** Body text maintains an expansive `line-height` (1.75 to 2.0 ratio relative to font size) to allow complex diacritics and Arabic vocalizations (Tashkeel) ample breathing room without vertical collision.
- **Display Presence:** `display-hero` and `headline-lg` represent literary chapters, book showcase crowns, and institutional milestones.
- **RTL Fluidity:** Text alignment defaults strictly to `right` across all narrative paragraphs and dashboard summaries. Punctuation brackets and numeric figures respect contextual text direction.

## Layout & Spacing

The structural layout draws from classical book margins, balancing structured management dashboards with expansive reading chambers.

### Spatial Discipline
- **Grid Architecture:** 12-column responsive grid on desktop viewports (max-width `1360px`), collapsing to 8 columns on tablet devices (`768px - 1024px`), and 4 fluid columns on mobile devices (`<768px`).
- **Reading Margins:** Dense informational grids (e.g., Club Supervisor dashboards, Branch inventory, Loyalty ledgers) utilize `gutter: 1.5rem`. Long-form reading containers constrain their reading measure to a focused `68ch` width centered on the screen.
- **RTL Alignment Logic:** Primary content flow originates from the right margin. Horizontal gaps (`gap-x`) and asymmetrical margins automatically mirror along the vertical axis without altering vertical rhythm.

## Elevation & Depth

This design system avoids loud, artificial dropshadows, relying instead on physical paper stacking, crisp surface boundaries, and warm ambient undertones.

### Depth Archetypes
- **Level 0 (Flat Canvas):** Default background (`#F9F6F0`). Used for root views, reading canvas backgrounds, and structural grid backdrops.
- **Level 1 (Paper Sheet):** Solid card surface (`#FFFFFF`) framed by a micro-hairline border `1px solid rgba(194, 166, 118, 0.35)`. Ambient blur: `0 2px 8px rgba(35, 78, 61, 0.04)`. Used for book cards, membership summaries, and forum discussion threads.
- **Level 2 (Raised Folio):** Used for interactive popovers, dropdown lists, and supervisory action toolbars. Surface elevated with shadow `0 8px 24px rgba(27, 56, 43, 0.08)` and subtle border tone `rgba(35, 78, 61, 0.12)`.
- **Level 3 (Modal Parlor):** Dialogues, registration drawers, and book review submission sheets. Overlay backdrop uses deep green mist `rgba(27, 56, 43, 0.4)` with backdrop-filter blur of `4px`.

## Shapes

With `roundedness: 2`, components reflect the gentle organic curve of bound paper and hand-stitched book spines, avoiding overly aggressive geometry or mechanical sharpness.

### Corner Radius System
- **Standard (`0.5rem` / 8px):** Buttons, standard inputs, discussion cards, administrative table cells, filter chips.
- **Large (`1rem` / 16px):** Book spotlight showcases, event banners, loyalty achievement modules, modal dialogues.
- **Extra Large (`1.5rem` / 24px):** Club session highlight containers and reading goal banners.
- **Full Pill (`9999px`):** Status pills, member badges, and category tags.

## Components

### Buttons
- **Primary Action (Emerald Foil):** Background `#234E3D`, label `#FFFFFF`, border `1px solid #1B382B`. Hover state shifts to `#1B382B` with a refined micro-lift. Focus ring: `2px solid #C2A676` with `2px` offset.
- **Secondary Literary (Gold Leaf):** Background `#F9F6F0`, label `#234E3D`, border `1px solid #C2A676`. Hover state introduces `#F2EDE2` fill with enhanced gold tone `#B39462`.
- **Tertiary / Ghost:** No background; label `#234E3D`. Hover applies subtle emerald wash `rgba(35, 78, 61, 0.06)`.

### Book Cards & Showcase Units
- White card canvas framed by hairline border `rgba(194, 166, 118, 0.3)`.
- Vertical aspect ratio `2:3` for book covers, anchored by an inset spine shadow effect on the right edge (for RTL presentation).
- Card metadata contains book title in `headline-sm`, author name in `body-sm` muted ink, and an inline status chip indicating discussion schedule or branch availability.

### Form Inputs & Textareas
- Background `#FFFFFF`, border `1px solid #DCD3C1`, border radius `0.5rem`.
- Padding: `0.75rem 1rem`. Right-aligned text orientation with mirrored icon positioning.
- Active/Focus: Border transitions to `#234E3D`, accompanied by a warm gold glow ring `rgba(194, 166, 118, 0.3)`.
- Error State: Terracotta red border `#9C382A` with warm blush background `#FDF4F2`.

### Chips & Badges
- **Loyalty Points & Milestones:** Background `#F2EDE2`, text `#1B382B`, adorned with an iconic gold star or quill badge in `#C2A676`.
- **Discussion Genre Chips:** Background `rgba(35, 78, 61, 0.08)`, text `#234E3D`, radius `9999px`, with gentle hover darkening.

### Checkboxes & Radio Controls
- Base dimension `20px x 20px`. Border `1.5px solid #234E3D`, radius `4px` for checkboxes and `50%` for radios.
- Selected State: Filled with `#234E3D`, revealing a clean `#FFFFFF` checkmark or gold inner dot.

### Lists & Activity Feeds
- Delimited with fine parchment divider rules `1px solid rgba(194, 166, 118, 0.2)`.
- Trailing metadata (points earned, timestamp, discussion seats remaining) anchored cleanly on the left edge in RTL format.

### Administration & Branch Dashboards
- **Metric Cards:** Crisp white cards displaying club branch KPIs, member registration volume, and facilitator attendance with gold accent lines along the top border.
- **Data Tables:** Headers set in `#F2EDE2` with `#234E3D` typography in `label-lg`; alternating row strips with soft `rgba(249, 246, 240, 0.5)` hover highlights.